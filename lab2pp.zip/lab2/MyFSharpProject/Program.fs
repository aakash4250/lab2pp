﻿
let applyExponent exponent value = 
    value ** float exponent


let square = applyExponent 2
let cube = applyExponent 3


let squareResults = [square 2.0; square 3.0; square 4.0]
let cubeResults = [cube 2.0; cube 3.0; cube 4.0]


printfn "Square results: %A" squareResults
printfn "Cube results: %A" cubeResults


type Coach = {
    Name: string
    FormerPlayer: bool
    Experience: int
}


type Stats = {
    Wins: int
    Losses: int
}


type Team = {
    Name: string
    Coach: Coach
    Stats: Stats
}


let coaches = [
    { Name = "Quin Snyder"; FormerPlayer = true; Experience = 10 }
    { Name = "Joe Mazzulla"; FormerPlayer = false; Experience = 2 }
    { Name = "Jordi Fernandez"; FormerPlayer = false; Experience = 0 }
    { Name = "Charles Lee"; FormerPlayer = false; Experience = 0 }
    { Name = "Billy Donovan"; FormerPlayer = true; Experience = 9 }
]

let stats = [
    { Wins = 7; Losses = 11 }  
    { Wins = 15; Losses = 3 }  
    { Wins = 8; Losses = 10 }  
    { Wins = 6; Losses = 11 }  
    { Wins = 8; Losses = 11 }  
]


let teams = [
    { Name = "Atlanta Hawks"; Coach = List.item 0 coaches; Stats = List.item 0 stats }
    { Name = "Boston Celtics"; Coach = List.item 1 coaches; Stats = List.item 1 stats }
    { Name = "Brooklyn Nets"; Coach = List.item 2 coaches; Stats = List.item 2 stats }
    { Name = "Charlotte Hornets"; Coach = List.item 3 coaches; Stats = List.item 3 stats }
    { Name = "Chicago Bulls"; Coach = List.item 4 coaches; Stats = List.item 4 stats }
]


let successfulTeams = teams |> List.filter (fun team -> team.Stats.Wins > team.Stats.Losses)


let calculateSuccessPercentage team =
    let totalGames = float (team.Stats.Wins + team.Stats.Losses)
    (float team.Stats.Wins / totalGames) * 100.0

let teamSuccessPercentages = 
    teams |> List.map (fun team -> (team.Name, calculateSuccessPercentage team))


printfn "\nSuccess percentages for all teams:"
teamSuccessPercentages 
|> List.iter (fun (name, percentage) -> printfn "%s: %.2f%%" name percentage)


type Cuisine =
    | Korean
    | Turkish


type MovieType =
    | Regular
    | IMAX
    | DBOX
    | RegularWithSnacks
    | IMAXWithSnacks
    | DBOXWithSnacks

type Activity =
    | BoardGame
    | Chill
    | Movie of MovieType
    | Restaurant of Cuisine
    | LongDrive of int * float  

let calculateBudget (activity: Activity) =
    match activity with
    | BoardGame -> 0.0  
    | Chill -> 0.0      
    | Movie movieType -> 
        match movieType with
        | Regular -> 12.0
        | IMAX -> 17.0
        | DBOX -> 20.0
        | RegularWithSnacks | IMAXWithSnacks | DBOXWithSnacks -> 22.0
    | Restaurant cuisine -> 
        match cuisine with
        | Korean -> 70.0
        | Turkish -> 65.0
    | LongDrive (km, fuelCostPerKm) -> float km * fuelCostPerKm

let activities = [
    Movie Regular
    Restaurant Korean
    LongDrive (100, 0.15)
    Movie IMAXWithSnacks
    Restaurant Turkish
    LongDrive (250, 0.18)
]


printfn "\nActivity Budgets:"
activities 
|> List.iteri (fun i activity -> printfn "Activity %d: %.2f CAD" (i + 1) (calculateBudget activity))
